<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Submitlaporan extends CI_Controller {

	function __construct(){
        // Call the Model constructor
        parent::__construct(); 
        $this->load->model('m_submitlaporan');
    }

	public function index(){
		$id = $this->session->userdata('id');
		$notif=$this->m_submitlaporan->ambilnotif($id);
		$this->load->view('v_submitlaporan', ['notif'=>$notif]);
	}
 
	public function mulai_upload(){
		$nama = $this->session->userdata('nama');
		$id = $this->session->userdata('id');
		$filenama = $id . '_' . $nama . '_laporan';

		$config['upload_path']          = 'file/laporan';
		$config['file_name']            = $filenama;
		$config['overwrite']            = TRUE;
		$config['allowed_types']        = 'pdf';
		$config['max_size']             = 5120;
 
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
 
		if ( ! $this->upload->do_upload('laporan')){
			echo "<script>alert('Upload gagal, pastikan file PDF dan kurang dari 5MB');</script>";
			redirect('Submitsurvey','refresh');
		}else{
			$data = array('upload_data' => $this->upload->data());
			echo "<script>alert('Upload sukses..');</script>";
			redirect('homemahasiswa','refresh');
		}
	}
	
}